from selenium import webdriver
from fake_useragent import UserAgent
import random 
import time
from selenium.webdriver.support.ui import Select
from imagetyperzapi3.imagetyperzapi import ImageTyperzAPI

#Fake Useragent to make each request Unique
useragent = UserAgent()
profile = webdriver.FirefoxProfile()
profile.set_preference("general.useragent.override", useragent.random)
driver = webdriver.Firefox(firefox_profile=profile, executable_path="/usr/bin/geckodriver")

#Generate Random Names and grab them
driver.get("http://listofrandomnames.com/")
time.sleep(1)

#CLick 50 Button to generate 50 Names.
driver.find_element_by_xpath("/html/body/div/div[3]/div[1]/form/fieldset/div/div[1]/button[5]").click()
#Submit Button
driver.find_element_by_xpath("/html/body/div/div[3]/div[1]/form/fieldset/div/div[5]/button").click()

#Define First Name and grab it
fn_1 = driver.find_element_by_xpath("/html/body/div/div[3]/div[2]/ul/li[1]/a[1]").text

First_Names = [fn_1]

#Define Last Name and grab it
ln_1 = driver.find_element_by_xpath("/html/body/div/div[3]/div[2]/ul/li[1]/a[2]").text

Last_Names = [ln_1]

#Generate Email Name based on the generated Name above
driver.get("https://www.name-generator.org.uk/username/")

#Generate Birthyear 
birthyear = [ 1998, 1999, 2000, 2001, 2002]

#Choose Random Birthyear as age 
age = random.choice(birthyear)

print(fn_1) 
print(ln_1)
print(age)
time.sleep(1)

#With German IP it ask for Cookie Permissions. No need for this code on International IPs
#accept_cookies = driver.find_element_by_xpath("/html/body/div[1]/div/div/div[2]/button[2]").click()
time.sleep(1)

#Submit Button "Fill with Random Data"
randomdata = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[3]").click()
time.sleep(1)
#Clear Name and Birthyear fields and submit our generated Data.
clear_fn = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[7]").clear()
emailgen_fn = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[7]").send_keys(fn_1)

clear_mn = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[9]").clear()

clear_ln = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[11]").clear()
emailgen_ln = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[11]").send_keys(ln_1)

clear_by = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[13]").clear()
emailgen_by = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[13]").send_keys(age)
time.sleep(1)
emailgen_sub = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[4]").click()

#Grab all 5 suggestions and choose randomly one of them
sug_1 = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[1]").text
sug_2 = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[2]").text
sug_3 = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[3]").text
sug_4 = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[4]").text
sug_5 = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[5]").text
sug_6 = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[6]").text

emailname = [sug_1, sug_2, sug_3, sug_4, sug_5]

#Random Choice of Email anme
emailnamechoice = random.choice(emailname)
print(emailnamechoice)

#Define Password which is same for all Accounts
Password = "Pimmel69"

#Visit Protonmail
driver.get("https://protonmail.com/signup")
time.sleep(2)
#Find Free Signup Button
driver.find_element_by_class_name("text-primary").click()
#Scroll down
driver.execute_script("window.scrollTo(20,document.body.scrollHeight)")
#Click Free Plan
driver.find_element_by_id("freePlan").click()
time.sleep(3)
print("Wait for Protonmail to load")
time.sleep(3)


# This Part here wont work
driver.find_element_by_class_name("group-username")
time.sleep(1)
driver.find_element_by_name("username").send_keys(emailnamechoice)
driver.find_element_by_id("password").send_keys(Password)
driver.find_element_by_id("passwordc").send_keys(Password)
driver.find_element_by_xpath("/html/body/div/div/footer/button").click()
driver.find_elements_by_id("confirmModalBtn").click()


driver.find_element_by_xpath("//*[@data-sitekey]")


access_token = '3D7273CE099144C98666ADED053960FE'
ita = ImageTyperzAPI(access_token) 
balance = ita.account_balance()                       

p['page_url'] = driver.current_url
p['sitekey'] = driver.find_element_by_xpath("//*[@data-sitekey]").get_attribute("data-sitekey")

while ita.in_progress():
    time.sleep(10)

recaptcha_response = ita.retrieve_recaptcha(captcha_id)           # captcha_id is optional, if not given, will use last captcha id submited
driver.execute_script("document.getElementById('g-recaptcha-response').innerHTML = '"+recaptcha_response+"';")

# The captcha was successfully solved.
# So, like, login, or whatever.

