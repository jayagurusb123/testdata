from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException
from fake_useragent import UserAgent
import random 
import time
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from imagetyperzapi3.imagetyperzapi import ImageTyperzAPI
import csv
import pandas as pd  
from selenium.webdriver.support.ui import WebDriverWait

#Fake Useragent to make each request Unique
useragent = UserAgent()
profile = webdriver.FirefoxProfile()
profile.set_preference("general.useragent.override", useragent.random)
driver = webdriver.Firefox(firefox_profile=profile, executable_path="/Users/leonnilsschmidt/Documents/Python/geckodriver")

#Generate Random Names and grab them
driver.get("http://listofrandomnames.com/")
time.sleep(1)

#Check if Websites are online
print("Check if Websites are UP.....")
def isDisplayed1():
    try:
        driver.find_element_by_xpath("/html/body/div/div[3]/div[1]/form/fieldset/div/div[1]/button[5]")
    except NoSuchElementException:
        return False
    return True

if (isDisplayed1() == True):
    print('Page for Random Names loaded successfull !')
else:
    print('Site for Random Names did not respond :(')
    driver.quit()

#CLick 50 Button to generate 50 Names.
driver.find_element_by_xpath("/html/body/div/div[3]/div[1]/form/fieldset/div/div[1]/button[5]").click()
#Submit Button
driver.find_element_by_xpath("/html/body/div/div[3]/div[1]/form/fieldset/div/div[5]/button").click()

#Checking if site crashed.
print("Checking if Site is generating Names...")
def isDisplayed1_1():
    try:
        driver.find_element_by_xpath("/html/body/div/div[3]/div[2]/ul/li[1]/a[1]")
    except NoSuchElementException:
        return False
    return True

if (isDisplayed1_1() == True):
    print('Names generated successfull !')
else:
    print('Site did not respond :(')
    driver.quit()


#First Name Defined 
fn_1 = driver.find_element_by_xpath("/html/body/div/div[3]/div[2]/ul/li[1]/a[1]").text

First_Names = [fn_1]

#Last Name defined
ln_1 = driver.find_element_by_xpath("/html/body/div/div[3]/div[2]/ul/li[1]/a[2]").text

Last_Names = [ln_1]

print("Save Account Name Data.....")   
nme = [fn_1] 
deg = [ln_1] 
   
# dictionary of lists  
dict = {'First Name': nme, 'Last Name': deg}  
df = pd.DataFrame(dict) 
  
# saving the dataframe 
#df.to_csv('file1.csv', mode="a") 


#Generate the Email Username
driver.get("https://www.name-generator.org.uk/username/")
time.sleep(1)

#Check if the Website is online
print("Check if Email-Username Page is UP....")
def isDisplayed2():
    try:
        driver.find_element_by_id("fill_all")
    except NoSuchElementException:
        return False
    return True

if (isDisplayed2() == True):
    print('Page loaded successfull !')
    print("Filling with Random Data....")
    driver.find_element_by_id("fill_all").click()
else:
    print('Site did not respond :(')
    driver.quit()

#Generate a Random Birth Year
birthyear = [ "1998", "1999", "2000", "2001", "2002"]

age = random.choice(birthyear)

print("Save Birthyear Data.....")   
# dictionary of lists  
dict = {'First Name': nme, 'Last Name': deg, "Birthyear": age}  
df = pd.DataFrame(dict) 
  
# saving the dataframe 
#df.to_csv('file1.csv', mode="a") 

print("Our New First Name:" + fn_1) 
print("Our New Last Name:" + ln_1)
print("Our New Birthyear:")
print(age)
time.sleep(1)


#If German IP is use site willl requires Cookies
print("Checking if Site requires Cookies....")
def isDisplayed3():
    try:
        driver.find_element_by_xpath("/html/body/div[1]/div/div/div[2]/button[2]")
    except NoSuchElementException:
        return False
    return True

if (isDisplayed3() == True):
    print('Cookies are required !')
    driver.find_element_by_xpath("/html/body/div[1]/div/div/div[2]/button[2]").click
    print("Cookies accepted !")
else:
    print('You are using International IPs. No need for Cookies :)')

#accept_cookies = driver.find_element_by_xpath("/html/body/div[1]/div/div/div[2]/button[2]").click()
time.sleep(1)
#randomdata = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[3]").click()
time.sleep(1)
print("Clear Name and Birthyear Field and fill with our Data....")
clear_fn = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[7]").clear()
emailgen_fn = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[7]").send_keys(fn_1)

clear_mn = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[9]").clear()

clear_ln = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[11]").clear()
emailgen_ln = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[11]").send_keys(ln_1)

clear_by = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[13]").clear()
emailgen_by = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[13]").send_keys(age)
time.sleep(1)
emailgen_sub = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/form/input[4]").click()

print("Deciding which suggested Username will be used....")
sug_1 = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[1]").text
sug_2 = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[2]").text
sug_3 = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[3]").text
sug_4 = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[4]").text
sug_5 = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[5]").text
sug_6 = driver.find_element_by_xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[6]").text

emailname = [sug_1, sug_2, sug_3, sug_4, sug_5]

emailnamechoice = random.choice(emailname)
print("Decided for Username:" + emailnamechoice)
emn = [emailnamechoice] 
domains = [ "outlook.de", "outlook.com", "hotmail.com"]
domainchoice = random.choice(domains)
print(domainchoice)
dmn = [emailnamechoice + "@" + domainchoice ]

print("Save Email Name Data.....")   
# dictionary of lists  
dict = {'First Name': nme, 'Last Name': deg, "Birthyear": age, "Email Name": dmn}  
df = pd.DataFrame(dict) 
  
# saving the dataframe 
#df.to_csv('file1.csv', mode="a") 

#Generate valid SSN Number
driver.get("https://www.ssn-verify.com/generate")
print("Generating State of Origin....")
state = "California (CA)"
time.sleep(1)
select_state = Select(driver.find_element_by_id("state"))
select_state.select_by_visible_text(state)
time.sleep(1)
print("Generating SSN Data.....")
select_year = Select(driver.find_element_by_id("year"))
select_year.select_by_value(age)
print("Checking is Site uses Cookies....")
time.sleep(1)
def isDisplayed31():
    try:
        driver.find_element_by_xpath("/html/body/div[4]/div/div[2]/div[2]/input")
    except NoSuchElementException:
        return False
    return True

if (isDisplayed31() == True):
    print('Cookies are required !')
    driver.find_element_by_xpath("/html/body/div[4]/div/div[2]/div[2]/input").click
    print("Cookes accepted !")
else:
    print('You are using International IPs. No need for Cookies, again :)')
driver.find_element_by_id("ssn-submit").click()
time.sleep(3)
ssn_number = element = WebDriverWait(driver,30).until(EC.presence_of_element_located((By.CLASS_NAME, "result-ssn"))).text
ssn = ssn_number

print("SSN successfull created:")
print(ssn)
print("Save State of Origin  Data.....")   
print("Save SSN Data....")
# dictionary of lists  
dict = {'First Name': nme, 'Last Name': deg, "Birthyear": age, "Email Name": dmn, "State": state, "SSN": ssn}  
df = pd.DataFrame(dict) 
# saving the dataframe 
#df.to_csv('final_file.csv', mode="a")


#Generate USA Adress
driver.get("https://www.bestrandoms.com/random-address")
select_year = Select(driver.find_element_by_class_name("form-control"))
select_year.select_by_value("CA")
print("Generating USA Adress...")
time.sleep(1)
driver.find_element_by_xpath("/html/body/section[2]/div/div[2]/div[1]/div/div[2]/form/div[4]/div/button").click()
street = driver.find_element_by_xpath("/html/body/section[2]/div/div[2]/ul/li[1]/span[2]").text
city = driver.find_element_by_xpath("/html/body/section[2]/div/div[2]/ul/li[1]/span[3]").text
zipcode = driver.find_element_by_xpath("/html/body/section[2]/div/div[2]/ul/li[1]/span[5]").text
print("Generating Phone Number....")
phone = driver.find_element_by_xpath("/html/body/section[2]/div/div[2]/ul/li[1]/span[1]").text

# dictionary of lists  
dict = {'First Name': nme, 'Last Name': deg, "Birthyear": age, "Email Name": dmn, "State": state, "SSN": ssn, "Street": street, "City": city, "Zip Code": zipcode, "Phone Number": phone}  
df = pd.DataFrame(dict) 
# saving the dataframe 
#df.to_csv('final_file.csv', mode="a")


print("Decided for Username:" + emailnamechoice)

#Start Creating Microsoft Account
print("Create Microsoft Account....")
driver.get("https://signup.live.com/signup")
driver.find_element_by_xpath("/html/body/div[1]/div/div/div[2]/div/div[1]/div[3]/div/div[1]/div[5]/div/div/form/div/div[1]/fieldset/div[2]/div/div[3]/a").click()

#Create List with Domain Options
driver.find_element_by_xpath("/html/body/div[1]/div/div/div[2]/div/div[1]/div[3]/div/div[1]/div[5]/div/div/form/div/div[1]/fieldset/div[1]/div[3]/div[2]/div/input").send_keys(emailnamechoice)

print("Deciding which Domain will be used.....")
print("Decided for Domain:" + domainchoice)

time.sleep(1)
select_domain = Select(driver.find_element_by_id("LiveDomainBoxList"))
time.sleep(1)
#Choose Random Domain Pre-Fix
select_domain.select_by_visible_text(domainchoice)
driver.find_element_by_xpath("/html/body/div[1]/div/div/div[2]/div/div[1]/div[3]/div/div[1]/div[5]/div/div/form/div/div[1]/div[2]/div/div/div/div[3]/input").click()
print("Filling out Input Fields....")
Password = "Pimmel69"
time.sleep(1)
#Send Password and Name Data
driver.find_element_by_name("Password").send_keys(Password)
driver.find_element_by_id("iSignupAction").click()
time.sleep(1)
driver.find_element_by_id("FirstName").send_keys(fn_1)
driver.find_element_by_id("LastName").send_keys(ln_1)

driver.find_element_by_id("iSignupAction").click()

birthdate = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 ,14 , 15, 16, 17]
bd = random.choice(birthdate)
time.sleep(1)
print("Setting Birthday (cause the whole Life is a Joke ^^)")
select_element = Select(driver.find_element_by_id("BirthDay"))
select_element.select_by_visible_text("1")
select_element2 = Select(driver.find_element_by_id("BirthMonth"))
select_element2.select_by_visible_text("April")
select_element3 = Select(driver.find_element_by_id("BirthYear"))
select_element3.select_by_visible_text("2000")

print("Save Input Data.....")
# dictionary of lists  
dict = {'First Name': nme, 'Last Name': deg, "Birthyear": age, "Email Name": dmn, "State": state, "SSN": ssn, "Street": street, "City": city, "Zip Code": zipcode, "Phone Number": phone, "Password": Password, "Used Domain": domainchoice}  
df = pd.DataFrame(dict) 
#saving the dataframe 
df.to_csv('final.csv', mode="a", header=False)

driver.find_element_by_id("iSignupAction").click()
time.sleep(5)

print("Check if Captcha is generated.....")

def isDisplayed4():
    try:
        driver.find_element_by_xpath("//div[@class='col-xs-12']/img")
    except NoSuchElementException:
        return False
    return True

if (isDisplayed4() == True):
    print('Captcha loaded successfull !')
else:
    print('Site requires Phone Verification :(')
    driver.quit()


captcha= driver.find_elements_by_xpath("//div[@class='col-xs-12']/img")
print("Getting Captcha URL to Break it !")
for image in captcha:
    img_src = image.get_attribute("src") 

print("Captcha URL loaded successfull: " + img_src)
access_token = '3D7273CE099144C98666ADED053960FE'
ita = ImageTyperzAPI(access_token)
balance = ita.account_balance() 
print("Your have " + balance + "credits left")
print ('Solving captcha ...')
captcha_solved = ita.solve_captcha(img_src) 
print("Captcha was cracked succesfully !")
print ('Captcha text: {}'.format(captcha_solved))
print("Sending the Captcha Solution to Microsoft...")

driver.find_element_by_css_selector("input").send_keys(captcha_solved)
driver.find_element_by_id("iSignupAction").click()
time.sleep(3)

def isDisplayed5():
    try:
        driver.find_element_by_class_name("help-footer")
    except NoSuchElementException:
        return False
    return True

if (isDisplayed5() == True):
    print('Account Creation successfull :D ! Awesome Job')
    print("Application will close now")
    time.sleep(2)
    driver.quit()
else:
    print('Site requires Phone Verification, please try again :(')
    driver.quit()







